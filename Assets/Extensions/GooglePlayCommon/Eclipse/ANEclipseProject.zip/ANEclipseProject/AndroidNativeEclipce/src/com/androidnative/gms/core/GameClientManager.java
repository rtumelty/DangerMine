package com.androidnative.gms.core;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.billing.util.Base64;
import com.androidnative.billing.util.Base64DecoderException;
import com.androidnative.gcm.network.RealTimeMultiplayerController;
import com.androidnative.gms.listeners.appstate.StateDeleteListener;
import com.androidnative.gms.listeners.appstate.StateUpdateListener;
import com.androidnative.gms.listeners.appstate.StatesLoadedListener;
import com.androidnative.gms.listeners.games.AchievementsLoadListner;
import com.androidnative.gms.listeners.games.AchievementsUpdateListner;
import com.androidnative.gms.listeners.games.LeaderBoardScoreLoaded;
import com.androidnative.gms.listeners.games.LeaderBoardsLoadedListener;
import com.androidnative.gms.listeners.games.PlayerResultListner;
import com.androidnative.gms.listeners.games.PlayerScoreUpdateListner;
import com.androidnative.gms.listeners.games.ScoreSubmitedListner;
import com.androidnative.gms.listeners.quests.AN_AcceptQuestResultListner;
import com.androidnative.gms.listeners.quests.AN_ClaimMilestoneResult;
import com.androidnative.gms.listeners.quests.AN_EventsLoadListner;
import com.androidnative.gms.listeners.quests.AN_LoadQuestsResult;
import com.androidnative.gms.listeners.quests.AN_QuestUpdateListener;
import com.androidnative.gms.listeners.requests.UpdateRequestsResultListner;
import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.appstate.AppStateStatusCodes;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.games.quest.QuestUpdateListener;
import com.google.android.gms.games.quest.Quests;
import com.google.android.gms.games.request.GameRequest;
import com.unity3d.player.UnityPlayer;

@SuppressLint("NewApi")
public class GameClientManager implements GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks , QuestUpdateListener {

	protected NewGameHelper mHelper;

	public static final int ACHIEVEMENTS_REQUEST = 20001;
	public static final int LEADER_BOARDS_REQUEST = 20002;
	public static final int GIFT_REQUEST = 20003;
	public static final int REQUESTS_INBOX_DIALOG = 20004;	
	
	public static final int RC_SELECT_PLAYERS = 10000;
	public static final int RC_INVITATION_INBOX = 10001;
	public static final int RC_WAITING_ROOM = 10002;
	
	

	public static final String CONNECTION_LISTNER_NAME = "GooglePlayConnection";
	public static final String PlAY_SERVICE_LISTNER_NAME = "GooglePlayManager";
	public static final String GOOGLE_PlAY_EVENTS_LISTNER_NAME = "GooglePlayEvents";
	public static final String GOOGLE_PlAY_QUESTS_LISTNER_NAME = "GooglePlayQuests";
	
	
	public static final String GOOGLE_CLOUD_LISTNER_NAME = "GoogleCloudManager";
	public static final String GOOGLE_PLAY_RTM_LISTENER = "GooglePlayRTM";
	
	
	private static boolean ReconectOnStart = false;

	private static boolean isStarted = false;
	
	public static ArrayList<String> loadedPlayers = new ArrayList<String>();
	
	/*
     * If we have incoming requests when we connected to the games client, they
     * are here. Otherwise, it's null.
     */
    ArrayList<GameRequest> mRequests;
    public static HashMap<String, GameRequest> gameRequestMap = new HashMap<String, GameRequest>();
    private static GameClientManager _instance = null;
    

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------
    
    public static GameClientManager GetInstance() {
		if (_instance == null) {
			_instance = new GameClientManager();
		}

		return _instance;
	}
    
	
	public void InitPlayService(String scopes) {
		printLog("Creating New GC");
		
		if (!isStarted()) {
			isStarted = true;
			mHelper = new NewGameHelper(this, scopes);
			RealTimeMultiplayerController.GetInstance().SetGameHelper(mHelper);
		}
	}

	

	public void sighIn() {
		if(isStarted) {
			if(mHelper != null) {
				
				if(!IsPlayServiceAlavliable()) {
					onSignInFailed();
					return;
				}
				mHelper.sighIn();
			}
		}
	}
	
	public void sighIn(String accountName) {
		if(isStarted) {
			if(mHelper != null) {
				if(!IsPlayServiceAlavliable()) {
					onSignInFailed();
					return;
				}
				
				mHelper.sighIn(accountName);
			}
		}
	}
	


	

	// --------------------------------------
	// SHOULD BE REFERED FROM ACTIVITY
	// --------------------------------------

	public void onStop() {
		ReconectOnStart = mHelper.IsConnected();
		RealTimeMultiplayerController.GetInstance().OnStop();
		
		disconnect();
		
	}
	
	public void onStart() {
		if(ReconectOnStart) {
			Log.d("AndroidNative", "Reconnection on start");
			connect();
		} else {
			Log.d("AndroidNative", "Skupping Reconnection on start");
		}
	}


	
	// --------------------------------------
	// QUESTS AND EVENTS
	// --------------------------------------
	
	public void sumbitEvent(String eventId, int count) {
	    // increment the event counter
	    Games.Events.increment(mHelper.getGoogleApiClient(), eventId, count);
	}
	
	public void loadEvents() {
		 Games.Events.load(mHelper.getGoogleApiClient(), true).setResultCallback(new AN_EventsLoadListner());
	}
	

	
	public void showQuests() {
		Intent questsIntent = Games.Quests.getQuestsIntent(mHelper.getGoogleApiClient(), Quests.TZ);
		AndroidNativeBridge.GetInstance().startActivityForResult(questsIntent, 0);
	}
	
	
	public void showSelectedQuests(String questSelectors) {

		Intent questsIntent = Games.Quests.getQuestsIntent(mHelper.getGoogleApiClient(), getQuestSelectors(questSelectors));
		AndroidNativeBridge.GetInstance().startActivityForResult(questsIntent, 0);
		
	}
	
	public void showQuest(String questId) {
		Intent questsIntent = Games.Quests.getQuestIntent(mHelper.getGoogleApiClient(), questId);
		AndroidNativeBridge.GetInstance().startActivityForResult(questsIntent, 0);
	}
	
	public void acceptQuest(String questId) {
		Games.Quests.accept(mHelper.getGoogleApiClient(), questId).setResultCallback(new AN_AcceptQuestResultListner());
	}
	
	public void loadQuests(String questSelectors, int sortOrder) {
		Games.Quests.load(mHelper.getGoogleApiClient(), getQuestSelectors(questSelectors), sortOrder, true).setResultCallback(new AN_LoadQuestsResult());
	}
	
	public void claimQuest(Quest quest) {
		 Games.Quests.claim(mHelper.getGoogleApiClient(), quest.getQuestId(),quest.getCurrentMilestone().getMilestoneId()).setResultCallback(new AN_ClaimMilestoneResult());
	}
	
	public void updateQuest(Quest quest) {
		StringBuilder result = new StringBuilder();
		
		result.append(quest.getQuestId());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(quest.getName());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(quest.getDescription());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		result.append(quest.getBannerImageUrl());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(quest.getIconImageUrl());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		result.append(quest.getState());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		
		
		result.append(quest.getLastUpdatedTimestamp());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(quest.getAcceptedTimestamp());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(quest.getEndTimestamp());
		
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_QUESTS_LISTNER_NAME, "OnGPQuestUpdated", result.toString());
		
	}
	
	
	
	
	
	
	
	private static final String QUEST_QUERY_SEPARATOR = ",";
	public int[] getQuestSelectors(String questSelectors) {
		int[] values =  new int[0];
		if(questSelectors != null && questSelectors.length() > 0) {
			String[] requests = questSelectors.split(QUEST_QUERY_SEPARATOR);
			values = new int[requests.length];
			
			int index = 0;
			for(String query : requests) {
				values[index] = Integer.valueOf(query);
				index++;
			}
		}
		
		return values;
	}
	
	
	// --------------------------------------
	// CLOUD METHODS
	// --------------------------------------

	public void listStates() {
		AppStateManager.list(mHelper.getGoogleApiClient()).setResultCallback(new StatesLoadedListener());
	}

	public void resolveState(int stateKey, String resolvedData, String resolvedVersion) {
		
		byte[] stateData = ConvertStringToCloudData(resolvedData);
		AppStateManager.resolve(mHelper.getGoogleApiClient(), stateKey, resolvedVersion, stateData).setResultCallback(new StateUpdateListener());
	}

	public void updateState(int stateKey, String data) {
		CloudUpdateState(stateKey, ConvertStringToCloudData(data));
	}

	private void CloudUpdateState(int stateKey, byte[] stateData) {
		AppStateManager.updateImmediate(mHelper.getGoogleApiClient(), stateKey, stateData).setResultCallback(new StateUpdateListener());
	}

	public void deleteState(int stateKey) {
		AppStateManager.delete(mHelper.getGoogleApiClient(), stateKey).setResultCallback(new StateDeleteListener());
	}

	public void loadState(int stateKey) {
		AppStateManager.load(mHelper.getGoogleApiClient(), stateKey).setResultCallback(new StateUpdateListener());
	}

	// --------------------------------------
	// GAME SERVICE METHODS
	// --------------------------------------

	
	public void loadConnectedPlayers() {
		Games.Players.loadConnectedPlayers(mHelper.getGoogleApiClient(), true).setResultCallback(new PlayerResultListner());
		
	}
	
	
	public void loadPlayerInfo(String playerId) {
		if(!isPlayerLoaded(playerId)) {
			addLoadedPlayerId(playerId);
			Games.Players.loadPlayer(mHelper.getGoogleApiClient(), playerId).setResultCallback(new PlayerResultListner());

		}
	}
	
	
	
	public void  loadGoogleAccountNames() {
		
		AccountManager mAccountManager = AccountManager.get(AndroidNativeBridge.GetInstance());
		
		
		StringBuilder result = new StringBuilder();
	    Account[] accounts = mAccountManager.getAccountsByType( GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE);
	    for (int i = 0; i < accounts.length; i++) {
			result.append( accounts[i].name);
			result.append(AndroidNativeBridge.UNITY_SPLITTER);
			
	    }
		result.append(AndroidNativeBridge.UNITY_EOF);
	    
		
	    UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnAccountsLoaded", result.toString());
	}
	
	
	
	public void getToken(String accountName, String scope) {
		
		String tocken = "";
		try {
			tocken =  GoogleAuthUtil.getToken(AndroidNativeBridge.GetInstance(), accountName, scope);
		} catch (Exception e) {
			 Log.d("AndroidNative", e.getMessage());
		}
		
		
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnTockenLoaded", tocken);
	}
	
	
	public void getToken() {
		
		AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {

			@Override
			protected Void doInBackground(Void... params) {
				String tocken = "";
				try {
					String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
					tocken =  GoogleAuthUtil.getToken(AndroidNativeBridge.GetInstance(), accountName, "oauth2:" + Games.SCOPE_GAMES.eP());

					 Log.d("AndroidNative", "tocken: " + tocken);
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage() + e);
				}
				
				UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnTockenLoaded", tocken);
				return null;
			}
	          
		};
	   task.execute((Void)null);
	}
	

	public void invalidateToken(String token) {
		GoogleAuthUtil.invalidateToken(AndroidNativeBridge.GetInstance(), token);
	}
	

	public void resetLeaderBoard(String leaderboardId) {

		AsyncTask<String, String, String> task = new AsyncTask<String, String, String>() {

			@Override
			protected String doInBackground(String... params) {
				try {
					String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
					String tocken =  GoogleAuthUtil.getToken(AndroidNativeBridge.GetInstance(), accountName, "oauth2:" + Games.SCOPE_GAMES.eP());

					// Reset scores
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(
							"https://www.googleapis.com" + 
							"/games/v1management" +
							"/leaderboards/" +
							params[0] + 
							"/scores/reset" +
							"?access_token=" + tocken);
					
					
					client.execute(post);
					
					 
					 
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage() + e);
				}
				
				 Log.d("AndroidNative", "resetLeaderBoard done");
				
				return null;
			}
 
		};
		
	   task.execute(leaderboardId);
	}
	
	public void resetAllAchievements() {
		AsyncTask<String, String, String> task = new AsyncTask<String, String, String>() {

			@Override
			protected String doInBackground(String... params) {
				try {
					String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
					String tocken =  GoogleAuthUtil.getToken(AndroidNativeBridge.GetInstance(), accountName, "oauth2:" + Games.SCOPE_GAMES.eP());
					
					// Reset scores
					HttpClient client = new DefaultHttpClient();
					String r = "https://www.googleapis.com/games/v1management/achievements/reset?access_token=" + tocken;
					HttpPost post = new HttpPost(r );
					client.execute(post);
					 
					Log.d("AndroidNative", r);
					 
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage() + e);
				}
				
				GameClientManager.GetInstance().loadAchievements();
				Log.d("AndroidNative", "resetAllAchievements done");

				return null;
			}
 
		};
		
	   task.execute("");
	}
	
	public void resetAchievement(String achievementId) {
		AsyncTask<String, String, String> task = new AsyncTask<String, String, String>() {

			@Override
			protected String doInBackground(String... params) {
				try {
					String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
					String tocken =  GoogleAuthUtil.getToken(AndroidNativeBridge.GetInstance(), accountName, "oauth2:" + Games.SCOPE_GAMES.eP());
					
					// Reset scores
					HttpClient client = new DefaultHttpClient();
					String r = "https://www.googleapis.com/games/v1management/achievements/" + params[0] + "/reset?access_token=" + tocken;
					HttpPost post = new HttpPost(r );
					client.execute(post);
					 
					 Log.d("AndroidNative", r);
					 
				} catch (Exception e) {
					 Log.d("AndroidNative", e.getMessage() + e);
				}
				
				GameClientManager.GetInstance().loadAchievements();
				 Log.d("AndroidNative", "resetAchievement done");

				return null;
			}
 
		};
		
	   task.execute(achievementId);
	}
	
	

	// --------------------------------------
	// LEADER_BOARD
	// --------------------------------------

	public void showLeaderBoardsUI() {
		AndroidNativeBridge.GetInstance().startActivityForResult(
				Games.Leaderboards.getAllLeaderboardsIntent(mHelper.getGoogleApiClient()), 
				LEADER_BOARDS_REQUEST);
	}

	public void showLeaderBoardUI(String leaderboardId) {
		AndroidNativeBridge.GetInstance().startActivityForResult(
				Games.Leaderboards.getLeaderboardIntent(mHelper.getGoogleApiClient(), leaderboardId), 
				LEADER_BOARDS_REQUEST);
	}

	public void submitScore(String leaderboardId, int score) {
		Games.Leaderboards.submitScoreImmediate(mHelper.getGoogleApiClient(), leaderboardId, score).setResultCallback(new ScoreSubmitedListner());
	}

	
	
	public void loadLeaderBoards() {
		Games.Leaderboards.loadLeaderboardMetadata(mHelper.getGoogleApiClient(), true).setResultCallback(new LeaderBoardsLoadedListener());
	}

	
	public void loadPlayerCenteredScores(String leaderboardId, int span, int leaderboardCollection, int maxResults) {
		  Log.d("AndroidNative", "loadPlayerCenteredScores");
		  Log.d("AndroidNative", Integer.toString(leaderboardCollection) );
		  Log.d("AndroidNative", Integer.toString(span) );
		  Games.Leaderboards.loadPlayerCenteredScores(mHelper.getGoogleApiClient(), leaderboardId, span, leaderboardCollection, maxResults, true).setResultCallback(new LeaderBoardScoreLoaded(span, leaderboardCollection, leaderboardId));
	}
	
	public void UpdatePlayerScore(String leaderboardId, int span, int leaderboardCollection) {
		Games.Leaderboards.loadCurrentPlayerLeaderboardScore(mHelper.getGoogleApiClient(), leaderboardId, span, leaderboardCollection).setResultCallback(new PlayerScoreUpdateListner(span, leaderboardCollection, leaderboardId));
	}
	
	public void loadTopScores(String leaderboardId, int span, int leaderboardCollection, int maxResults) {
		Games.Leaderboards.loadTopScores(mHelper.getGoogleApiClient(), leaderboardId, span, leaderboardCollection, maxResults, true).setResultCallback(new LeaderBoardScoreLoaded(span, leaderboardCollection, leaderboardId));
	}
	
	

	// --------------------------------------
	// ACHIVMENTS
	// --------------------------------------

	public void showAchivmentsUI() {
		
		AndroidNativeBridge.GetInstance().startActivityForResult(
				Games.Achievements.getAchievementsIntent(mHelper.getGoogleApiClient()), 
				ACHIEVEMENTS_REQUEST);
	}
	
	 

	public void reportAchievement(String id) {
		Games.Achievements.unlockImmediate(mHelper.getGoogleApiClient(), id).setResultCallback(new AchievementsUpdateListner());
	}

	public void incrementAchievement(String id, int numSteps) {
		Games.Achievements.incrementImmediate(mHelper.getGoogleApiClient(), id, numSteps).setResultCallback(new AchievementsUpdateListner());	
		
	}

	public void revealAchievement(String id) {	
		Games.Achievements.revealImmediate(mHelper.getGoogleApiClient(), id).setResultCallback(new AchievementsUpdateListner());
	}

	public void loadAchievements() {
		
		loadAchievements(true);
	}
	
	public void loadAchievements(boolean forseLoad) {
		
		Games.Achievements.load(mHelper.getGoogleApiClient(), forseLoad).setResultCallback(new AchievementsLoadListner());
	}



	public void disconnect() {
		mHelper.disconnect();
	}
	
	public void connect() {
		mHelper.connect();
	}

	public void showAlert(String title, String message) {
		//mHelper.showAlert(title, message);
	}

	public void showAlert(String message) {
		//mHelper.showAlert(message);
	}

	 /**
     * Called when {@code mGoogleApiClient} is connected.
     */
    @Override
    public void onConnected(Bundle connectionHint) {
        Log.d("AndroidNative", "GoogleApiClient connected");
        
        StringBuilder result = new StringBuilder();
        Player player = Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient());
		
		result.append(player.getPlayerId());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(player.getDisplayName());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(player.getHiResImageUrl());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(player.getIconImageUrl());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		if(player.hasIconImage()) {
			result.append(1);
		} else {
			result.append(0);
		}
		
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		if(player.hasHiResImage()) {
			result.append(1);
		} else {
			result.append(0);
		}
		
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		String accountName  = Games.getCurrentAccountName((mHelper.getGoogleApiClient()));
		result.append(accountName);
		Log.d("AndroidNative", "accountName " + accountName);
        
        UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnPlayerDataLoaded", result.toString());
        
       
        
        //Do we have any requests pending?
        mRequests = Games.Requests.getGameRequestsFromBundle(connectionHint);
        Log.d("AndroidNative", "onConnected: connection hint has " + mRequests.size() + " request(s)");
        
        if (!mRequests.isEmpty()) {
            // We have requests in onConnected's connectionHint.
           
        	result = new StringBuilder();
            for(GameRequest r : mRequests) {
            	result.append( r.getRequestId());
            	result.append(AndroidNativeBridge.UNITY_SPLITTER);
            	String decoded = "";
				try {
					decoded = new String( r.getData(), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} 
            	result.append(decoded);
            	result.append(AndroidNativeBridge.UNITY_SPLITTER);
            	result.append(r.getExpirationTimestamp() );
            	result.append(AndroidNativeBridge.UNITY_SPLITTER);
            	result.append(r.getCreationTimestamp() );
            	result.append(AndroidNativeBridge.UNITY_SPLITTER);
            	result.append(r.getSender().getPlayerId() );
            	result.append(AndroidNativeBridge.UNITY_SPLITTER);
            	result.append(r.getType());
            	result.append(AndroidNativeBridge.UNITY_SPLITTER);
            	
            }
            result.append(AndroidNativeBridge.UNITY_EOF);
            
        	UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGameRequestsLoaded", result.toString());
        } else {
        	UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGameRequestsLoaded", "");
        }
        
        result = new StringBuilder();
		result.append(0);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(0);
	
		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnConnectionResult", result.toString());
		
		RealTimeMultiplayerController.GetInstance().onConnected(connectionHint);
		Games.Quests.registerQuestUpdateListener(mHelper.getGoogleApiClient(), new AN_QuestUpdateListener());
		//Games.Quests.registerQuestUpdateListener(mHelper.getGoogleApiClient(), this);
		
		Log.d("AndroidNative", "AN_QuestUpdateListener registred");
	
    }
    
    
	public void onNewIntent(Intent intent) {
		//mRequests = Games.Requests.getGameRequestsFromInboxResponse(intent);
       mHelper.reconnect();

	}
    
    
	// --------------------------------------
	// GIFTS
	// --------------------------------------
    
    public void sendGiftRequest(String type, String playload, String requestLifetimeDays, String icon, String description) {
	
		try {
			byte[] byteArray;
			byteArray = Base64.decode(icon);
			Bitmap media = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
			 
	    	
	    	Intent intent = Games.Requests.getSendIntent(mHelper.getGoogleApiClient(), Integer.valueOf(type), playload.getBytes(), Integer.valueOf(requestLifetimeDays), media, description);
	    	AndroidNativeBridge.GetInstance().startActivityForResult(intent, GIFT_REQUEST);
	   
	    	Log.d("AndroidNative", String.valueOf(GIFT_REQUEST));
	    	
		} catch (Base64DecoderException e) {
     		
     		UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGiftSendResult", "0");
			Log.d("AndroidNative", "sendGiftRequest: failed");
			e.printStackTrace();
		}
	}
    
    public void showRequestAccepDialog() {
    	AndroidNativeBridge.GetInstance().startActivityForResult(Games.Requests.getInboxIntent(mHelper.getGoogleApiClient()), REQUESTS_INBOX_DIALOG);
    }
    
    public void loadGiftRequsts() {
    	
    }
    
    
    public void acceptRequests(String ids) {
    	if(ids != null && ids.length() > 0) {
    		
    		ArrayList<GameRequest> list = new ArrayList<GameRequest>();
    		
			for(String id : ids.split(AndroidNativeBridge.UNITY_SPLITTER)) {
				for(GameRequest r : mRequests) {
					if(r.getRequestId().equals(id)) {
						list.add(r);
					}
				}
			}
			
			if(!list.isEmpty()) {
				acceptRequests(list);
			}
    	}
    	
    }
    
    public void dismissRequest(String ids) {
    	if(ids != null && ids.length() > 0) {
    		
    		ArrayList<GameRequest> list = new ArrayList<GameRequest>();
    		
			for(String id : ids.split(AndroidNativeBridge.UNITY_SPLITTER)) {
				for(GameRequest r : mRequests) {
					if(r.getRequestId().equals(id)) {
						list.add(r);
					}
				}
			}
			
			if(!list.isEmpty()) {
				dismissRequest(list);
			}
    	}
    	
    }
    
    
    public void acceptRequests(ArrayList<GameRequest> requests) {
    	// Attempt to accept these requests.
        ArrayList<String> requestIds = new ArrayList<String>();
        gameRequestMap  = new HashMap<String, GameRequest>();
        
        for (GameRequest request : requests) {
            String requestId = request.getRequestId();
            requestIds.add(requestId);
            gameRequestMap.put(requestId, request);
        }
        
        Games.Requests.acceptRequests(mHelper.getGoogleApiClient(), requestIds).setResultCallback(new UpdateRequestsResultListner());
        
        
    }
    
    public void dismissRequest(ArrayList<GameRequest> requests) {
    	// Attempt to accept these requests.
        ArrayList<String> requestIds = new ArrayList<String>();
        gameRequestMap  = new HashMap<String, GameRequest>();
        
        for (GameRequest request : requests) {
            String requestId = request.getRequestId();
            requestIds.add(requestId);
            gameRequestMap.put(requestId, request);
        }
        
        Games.Requests.dismissRequests(mHelper.getGoogleApiClient(), requestIds);
        
    }
    
    

    
    public static boolean isPlayerLoaded(String id) {
    	if(loadedPlayers.contains(id)) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
    public static void addLoadedPlayerId(String id) {
    	if(!loadedPlayers.contains(id)) {
    		loadedPlayers.add(id);
    	}
    }
  

    /**
     * Called when {@code mGoogleApiClient} is disconnected.
     */
    @Override
    public void onConnectionSuspended(int cause) {
    	Log.d("AndroidNative", "onConnectionSuspended");
        Log.d("AndroidNative", "GoogleApiClient connection suspended");
    }
    
    public void onSignInFailed() {
    	Log.d("AndroidNative", "onSignInFailed");
    	 
    	StringBuilder result = new StringBuilder();
 		result.append(13);
 		result.append(AndroidNativeBridge.UNITY_SPLITTER);
 		result.append(0);


 		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnConnectionResult", result.toString());
    }


	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
		
	    Log.d("AndroidNative", "onConnectionFailed");
	    Log.d("AndroidNative", "Erro code:" +  Integer.toString(arg0.getErrorCode()));
	    Log.d("AndroidNative", "hasResolution: " + String.valueOf(arg0.hasResolution()));
		
		StringBuilder result = new StringBuilder();
		result.append(arg0.getErrorCode());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		if(arg0.hasResolution()) {
			result.append(1);
		} else {
			result.append(0);
		}
		
		
		
		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnConnectionResult", result.toString());
		
		if(arg0.hasResolution()) {
			mHelper.resolveConnection(arg0);
		}
		
		if(arg0.getErrorCode() == AppStateStatusCodes.STATUS_CLIENT_RECONNECT_REQUIRED) {
			mHelper.reconnect();
		}
		
		
	}
	
	public void onActivityResult(int request, int response, Intent data) {

		Log.d("AndroidNative", "GCM onActivityResult");

		switch (request) {
	        case ACHIEVEMENTS_REQUEST:
	        	Log.d("AndroidNative", "ACHIEVEMENTS_REQUEST returned");
	            break;
	        case GIFT_REQUEST:
	        	Log.d("AndroidNative", "Gift result code " + String.valueOf(response));
	
	        	StringBuilder result = new StringBuilder();
	     		result.append(response);
	     		
	     		UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnGiftSendResult", result.toString());
	     		
	     		break;
	        case REQUESTS_INBOX_DIALOG:
	        	Log.d("AndroidNative", "GCM REQUESTS_INBOX_DIALOG");
	            if (response == AndroidNativeBridge.RESULT_OK && data != null) {       
	            	Log.d("AndroidNative", "accepting requests");
	            	acceptRequests(Games.Requests.getGameRequestsFromInboxResponse(data));
	            } 
	            
	            UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnRequestsInboxDialogDismissed", "");
	            break;
		}
		
		RealTimeMultiplayerController.GetInstance().onActivityResult(request, response, data);
	
		mHelper.onActivityResult(request, response, data);
		
		
	}
	
	
	
	
	
	private void printLog(String msg) {
		Log.d("AndroidNative", "GameClientManager: " + msg);
	}

	public static String ConvertCloudDataToString(byte[] data) {
		String b = "";
		
		if(data == null) {
			return b;
		}

		int len = data.length;
		for (int i = 0; i < len; i++) {
			if (i != 0) {
				b += ",";
			}

			b += String.valueOf(data[i]);
		}

		return b;
	}

	public static byte[] ConvertStringToCloudData(String data) {
		
		String[] array = data.split("\\,");
		List<Byte> l = new ArrayList<Byte>();
		for (String b : array) {
			l.add(Byte.valueOf(b));
		}

		Byte[] B = l.toArray(new Byte[l.size()]);

		byte[] stateData = new byte[B.length];
		for (int i = 0; i < B.length; i++) {
			stateData[i] = B[i];
		}

		return stateData;
	}

	public static boolean isStarted() {
		return isStarted;
	}

	private boolean IsPlayServiceAlavliable() {
		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(AndroidNativeBridge.GetInstance());
		  
		if (resultCode == ConnectionResult.SUCCESS){
			return true;
		}
		 
		return false;
	}


	@Override
	public void onQuestCompleted(Quest arg0) {
		Log.d("AndroidNative", "onQuestCompleted: ");
		
	}


}
