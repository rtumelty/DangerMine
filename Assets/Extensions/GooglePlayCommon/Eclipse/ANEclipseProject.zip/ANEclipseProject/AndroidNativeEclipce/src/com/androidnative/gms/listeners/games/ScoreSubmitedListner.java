package com.androidnative.gms.listeners.games;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.leaderboard.LeaderboardVariant;
import com.google.android.gms.games.leaderboard.Leaderboards;
import com.google.android.gms.games.leaderboard.Leaderboards.SubmitScoreResult;
import com.unity3d.player.UnityPlayer;



public class ScoreSubmitedListner implements ResultCallback<Leaderboards.SubmitScoreResult> {

	@Override
	public void onResult(SubmitScoreResult arg0) {
		
		int statusCode = arg0.getStatus().getStatusCode();
		
		
		Log.d("AndroidNative", "Status: " + statusCode + " leaderboardId: " + arg0.getScoreData().getLeaderboardId());

		StringBuilder playerInfo = new StringBuilder();
		playerInfo.append(statusCode);
		playerInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
		playerInfo.append(arg0.getScoreData().getLeaderboardId());
		
		/*
		playerInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
		playerInfo.append(arg0.getScoreData().getScoreResult(LeaderboardVariant.TIME_SPAN_ALL_TIME).rawScore);
		playerInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
		playerInfo.append(arg0.getScoreData().getScoreResult(LeaderboardVariant.TIME_SPAN_WEEKLY).rawScore);
		playerInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
		playerInfo.append(arg0.getScoreData().getScoreResult(LeaderboardVariant.TIME_SPAN_DAILY).rawScore);
	
	*/
		
		GameClientManager.GetInstance().loadPlayerCenteredScores(arg0.getScoreData().getLeaderboardId(), LeaderboardVariant.TIME_SPAN_ALL_TIME, LeaderboardVariant.COLLECTION_PUBLIC, 1);
		
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnScoreSubmitted", playerInfo.toString());
		
	}
	
}
