package com.androidnative.features.ad;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.util.DisplayMetrics;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class ANMobileAd extends AdListener  {
	
	public static String AD_MOB_LISTNER_NAME = "AndroidAdMobController";
	
	private String AD_UNIT_ID = "";
	private String INTERSTISIALS_AD_UNIT_ID = "";
	
	
	private static ANMobileAd _instance = null;

	private static Activity mainActivity = null;
	private static AdRequest.Builder adRequestBuilder = null;
	
	
	private static HashMap<Integer, GADBanner> banners;
	
	
	
	private InterstitialAd interstitial = null;
	private InterstitialAdListner intListner = null;
	
	private boolean IsInited = false;
	
	
	@SuppressLint({ "NewApi", "UseSparseArrays" })
	public static ANMobileAd GetInstance() {
		if(_instance == null) {
			_instance =  new ANMobileAd();
			banners = new HashMap<Integer, GADBanner>();
		}
		
		
		return _instance;
	}
	
	
	
	public void Init(String ad_unit_id, Activity activity) {
		if(IsInited) {
			return;
		}
		
		IsInited = true;
		
		
		AD_UNIT_ID = ad_unit_id;
		INTERSTISIALS_AD_UNIT_ID = ad_unit_id;
		mainActivity = activity;
		adRequestBuilder =  new AdRequest.Builder();
		
		Log.d("AndroidNative", "Init ");
		
	}
	
	
	public void ChangeBannersUnitID(String ad_unit_id) {
		AD_UNIT_ID = ad_unit_id;
	}
	
	
	public void ChangeInterstisialsUnitID(String ad_unit_id) {
		INTERSTISIALS_AD_UNIT_ID = ad_unit_id;
		if(interstitial != null)  {
			interstitial.setAdUnitId(INTERSTISIALS_AD_UNIT_ID);
		}
	}
	

	
	
	public void AddKeyword(String keyword) {
		 if(!IsInited) {
			return;
		 }
		 
		 adRequestBuilder.addKeyword(keyword);	
	}
	
	public void SetBirthday(int year, int month, int day) {
		 if(!IsInited) {
				return;
		 }
		 Calendar cal = Calendar.getInstance();
		 cal.set(year, month, day);
		 
		 Date birthday = cal.getTime();

		 adRequestBuilder.setBirthday(birthday);
	}
	
	public void TagForChildDirectedTreatment(boolean tagForChildDirectedTreatment ) {
		 if(!IsInited) {
				return;
		 }
		 adRequestBuilder.tagForChildDirectedTreatment(tagForChildDirectedTreatment);
	}
	
	
	

	@SuppressLint("NewApi")
	public void AddTestDevice(String deviceId) {
		 if(!IsInited) {
			return;
		 }
		 Log.d("AndroidNative", "AddTestDevice ");
		 Log.d("AndroidNative", deviceId);
			
		
		 adRequestBuilder.addTestDevice(deviceId);
		
	}
	
	
	private static final String DEVICES_SEPARATOR = ",";
	/**
	 * By nastrandsky.
	 * Adds many test devices at once.
	 * @param csvDeviceIds comma separated device ids.
	 */
	public void AddTestDevices(String csvDeviceIds) {
		if(csvDeviceIds != null && csvDeviceIds.length() > 0)
			for(String deviceId : csvDeviceIds.split(DEVICES_SEPARATOR))
				AddTestDevice(deviceId);
	}
	
	
	
	public void SetGender(int gender) {
		 if(!IsInited) {
			return;
		 }
			 
		 adRequestBuilder.setGender(gender);
	}
	
	
	public void CreateBannerAd(int gravity, int size, int id) {
		

	 	 if(!IsInited) {
			return;
		 }
	
	 	Log.d("AndroidNative", "CreateBannerAd ");
	 	
	 	GADBanner banner = new GADBanner(gravity, size, id);
	 	banners.put(id, banner);


	}
	
	public void CreateBannerAd(int x, int y, int size, int id) {
		

	 	 if(!IsInited) {
			return;
		 }
	
	 	Log.d("AndroidNative", "CreateBannerAd ");
	 	
	 	GADBanner banner = new GADBanner(x, y, size, id);
	 	banners.put(id, banner);


	}
	
	
	/**
	 * By nastrandsky
	 * Sets the position of a banner without destroying it specifying a gravity.
	 */
	public void SetPosition(int gravity, int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.SetPosition(gravity);
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	
	/**
	 * By nastrandsky
	 * Sets the position of a banner without destroying it specifying X and Y coordinates.
	 */
	public void SetPosition(int x, int y, int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.SetPosition(x, y);
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	
	
	
	public void DestroyBanner(int bannerId) {

		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.Destroy();
			banners.remove(bannerId);
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	
	}
	
	
	private void InitInterstitialAd(Activity activity, String id) {
		if(interstitial == null) {
			Log.d("AndroidNative", "InitInterstitialAd: ");
			interstitial = new InterstitialAd(activity);
		    interstitial.setAdUnitId(id);
		    
		    intListner =  new InterstitialAdListner(interstitial);
			interstitial.setAdListener(intListner);
			interstitial.setInAppPurchaseListener(new AdInAppListner());
		}
	}
	
	
	public void StartInterstitialAd() {
		InitInterstitialAd(mainActivity, INTERSTISIALS_AD_UNIT_ID);

		intListner.IsShowAdOnLoad = true;
		interstitial.loadAd(GetAdRequestBuilder().build());
	   
	    

	}
	
	
	public void LoadInterstitialAd() {
		InitInterstitialAd(mainActivity, INTERSTISIALS_AD_UNIT_ID);

		intListner.IsShowAdOnLoad = false;
		interstitial.loadAd(GetAdRequestBuilder().build());
	}
	
	public void ShowInterstitialAd() {
		if(interstitial != null) {
			interstitial.show();
		} 
		
	}
	
	
	
	public void HideAd(int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.HideAd();
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	
	public void ShowAd(int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.ShowAd();
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	
	
	public void Refresh(int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.Refresh();
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	
	@SuppressLint("NewApi")
	public float getDensity() {
	    DisplayMetrics dm = new DisplayMetrics();
	    AndroidNativeBridge.GetInstance().getWindowManager().getDefaultDisplay().getMetrics(dm);
	    return dm.density;
	}

	
	public  Activity GetCurrentActivity() {
		return mainActivity;
	}
	
	public String GetAdUnitID() {
		return AD_UNIT_ID; 
	}
	
	public AdRequest.Builder GetAdRequestBuilder() {
		return adRequestBuilder;
	}

	

}

